import { NextResponse } from "next/server";

/**
 * GIRO/DIDBase: catálogo de estaciones + datos recientes por estación.
 *
 * Estrategia (evitando el POST masivo del C++ original, prohibido en serverless):
 *   1. Catálogo:  https://lgdc.uml.edu/common/DIDBFastStationList?orderByField=ursiCode (regex)
 *   2. Datos:     https://lgdc.uml.edu/fastchar/getbest?ursiCode=XXX&charName=foF2&fromDate=...&toDate=...
 *      -> Endpoint GET rápido por estación (el mismo que expone DIDBase).
 *      Consultamos en paralelo un subconjunto (~28 estaciones estratégicas globales)
 *      con cadencia de 10 min en el server, incluyendo historia (para replay).
 *
 * Caché: 10 min. El cliente puede pedir ?full=1 para todas las estaciones con dato.
 */

export const revalidate = 0;

const UA = "IonosphereLive3D-Web/1.0 (exploration demo)";
const CATALOG_URL = "https://lgdc.uml.edu/common/DIDBFastStationList?orderByField=ursiCode";
const GETBEST = "https://lgdc.uml.edu/fastchar/getbest";

/** 51 estaciones verificadas del catálogo GIRO (cobertura global, EB040 incluida) */
const CORE_STATIONS = [
  "EB040", // Roquetes, España (¡la del autor!)
  "EA036", // El Arenosillo, España
  "PQ052", "JR055", "KL154", "KI167", "FF051", "GM037", "AT138",
  "VT139", "OL246", "LD160", "MZ152", "RV149", "TR170", "RL052",
  "SO148", "TR169", "DB049", "EG931", "CS839", "BC840", "AC843",
  "EI764", "PF765", "AU930", "BVJ03", "SMK29", "TNJ20", "CAJ2M",
  "CXM9B", "BLJ03", "LA42Q", "DW41K", "CB53N", "TO535", "IC437",
  "DH224", "NI135", "XI434", "CS31K", "TV51R", "MA155", "MO155",
  "ML10L", "GR13L", "MU12K", "RM041", "NDA81", "TR0P2",
];

const uniq = Array.from(new Set(CORE_STATIONS));

interface StationInfo {
  code: string;
  name: string;
  lat: number;
  lon: number;
}

interface StationData {
  code: string;
  foF2: number | null;
  muf3000: number | null;
  history: { t: string; foF2: number }[];
}

let stationCache: { data: unknown; ts: number } | null = null;
let catalogCache: StationInfo[] | null = null;

function parseCatalog(html: string): StationInfo[] {
  const out: StationInfo[] = [];
  const re =
    /ursiCode=([A-Z0-9]{5})">[^<]*<\/a><\/big><\/td><td[^>]*><big>([^<]*)<\/big><\/td><td[^>]*><big>\s*(-?[0-9.]+)<\/big><\/td><td[^>]*><big>\s*(-?[0-9.]+)<\/big><\/td>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) !== null) {
    const code = m[1];
    const name = m[2].replace(/\t/g, " ").replace(/\s+/g, " ").trim();
    const lat = parseFloat(m[3]);
    let lon = parseFloat(m[4]);
    if (lon > 180) lon -= 360;
    if (isFinite(lat) && isFinite(lon)) out.push({ code, name, lat, lon });
  }
  return out;
}

async function fetchCatalog(): Promise<StationInfo[]> {
  if (catalogCache) return catalogCache;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 20000);
    const res = await fetch(CATALOG_URL, {
      headers: { "User-Agent": UA },
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return [];
    const html = await res.text();
    catalogCache = parseCatalog(html);
    return catalogCache;
  } catch {
    return [];
  }
}

function parseGetBest(text: string): StationData | null {
  const lines = text.split("\n").map((l) => l.replace(/\r$/, ""));
  const codeMatch = text.match(/URSI-Code\s+([A-Z0-9]{5})/);
  const code = codeMatch ? codeMatch[1] : "";
  const mufMatch = text.match(/DMUF=3000\s*:\s*([0-9.]+)/);
  const muf3000 = mufMatch ? parseFloat(mufMatch[1]) : null;
  const history: { t: string; foF2: number }[] = [];
  let foF2: number | null = null;
  for (const l of lines) {
    if (!l || l.startsWith("#") || l.startsWith("Time")) continue;
    const toks = l.trim().split(/\s+/);
    if (toks.length < 3) continue;
    const t = toks[0];
    const fo = parseFloat(toks[2]);
    if (!isFinite(fo)) continue;
    history.push({ t, foF2: fo });
  }
  if (history.length) {
    // último valor con CS>0 preferido; si no, el último
    for (let i = history.length - 1; i >= 0; i--) {
      if (history[i].foF2 > 0) {
        foF2 = history[i].foF2;
        break;
      }
    }
  }
  if (!code) return null;
  return { code, foF2, muf3000, history: history.slice(-72) }; // 6 h @ 5 min
}

async function fetchStation(code: string, now: Date): Promise<StationData | null> {
  const from = new Date(now.getTime() - 6 * 3600_000);
  const fmt = (d: Date) =>
    `${d.getUTCFullYear()}.${String(d.getUTCMonth() + 1).padStart(2, "0")}.${String(
      d.getUTCDate()
    ).padStart(2, "0")}T${String(d.getUTCHours()).padStart(2, "0")}:${String(
      d.getUTCMinutes()
    ).padStart(2, "0")}:00`;
  const url = `${GETBEST}?ursiCode=${code}&charName=foF2&fromDate=${fmt(from)}&toDate=${fmt(now)}`;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 12000);
    const res = await fetch(url, {
      headers: { "User-Agent": UA },
      signal: ctrl.signal,
      next: { revalidate: 0 },
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const text = await res.text();
    if (text.includes("STATUS: ERROR")) return null;
    return parseGetBest(text);
  } catch {
    return null;
  }
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const wantFull = url.searchParams.get("full") === "1";
  const cacheOk = stationCache && Date.now() - stationCache.ts < 600_000 && !wantFull;

  if (cacheOk && stationCache) {
    return NextResponse.json(stationCache.data, {
      headers: { "Cache-Control": "no-store", "X-Cache": "hit" },
    });
  }

  const catalog = await fetchCatalog();
  const now = new Date();

  // En modo full: todas las estaciones del catálogo (limitado a 80 para cortesía)
  const codes = wantFull
    ? catalog.slice(0, 80).map((s) => s.code)
    : uniq;

  // Paralelo con límite de concurrencia (6) + pausa de cortesía entre peticiones
  const results: StationData[] = [];
  const queue = [...codes];
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  async function worker() {
    while (queue.length) {
      const code = queue.shift()!;
      const d = await fetchStation(code, now);
      if (d && (d.foF2 !== null || d.history.length)) results.push(d);
      await sleep(250); // cortesía con LGDC (rate-limit 429)
    }
  }
  await Promise.all(Array.from({ length: 6 }, () => worker()));

  const byCode = new Map(catalog.map((s) => [s.code, s]));
  const stations = results
    .map((d) => {
      const info = byCode.get(d.code);
      return {
        code: d.code,
        name: info?.name ?? d.code,
        lat: info?.lat ?? 0,
        lon: info?.lon ?? 0,
        foF2: d.foF2,
        muf3000: d.muf3000,
        history: d.history,
      };
    })
    .filter((s) => s.lat !== 0 || s.lon !== 0 || s.foF2 !== null)
    .sort((a, b) => a.code.localeCompare(b.code));

  const data = {
    updated: Date.now(),
    stations,
    total: stations.length,
    catalogSize: catalog.length,
    source: "GIRO DIDBase (live, getbest)",
  };

  // no cachear el modo full tan agresivo (diagnóstico)
  if (!wantFull) {
    (stationCache as { data: unknown; ts: number }) = { data, ts: Date.now() };
  }
  return NextResponse.json(data, { headers: { "Cache-Control": "no-store", "X-Cache": "miss" } });
}
