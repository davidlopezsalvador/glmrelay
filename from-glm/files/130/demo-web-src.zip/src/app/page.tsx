"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { RadioTower, FlaskConical, Github, X, Signal } from "lucide-react";

import IonosphereScene from "@/components/ionosphere/IonosphereScene";
import SpaceWeatherPanel from "@/components/ionosphere/hud/SpaceWeatherPanel";
import LayersPanel from "@/components/ionosphere/hud/LayersPanel";
import RadioPanel from "@/components/ionosphere/hud/RadioPanel";
import TimeBar from "@/components/ionosphere/hud/TimeBar";
import Legend from "@/components/ionosphere/hud/Legend";
import IdeasPanel from "@/components/ionosphere/hud/IdeasPanel";

import {
  SpaceWeatherData,
  AuroraData,
  IonosondeData,
  SceneSettings,
  DEFAULT_SETTINGS,
} from "@/components/ionosphere/types";
import { LinkResult } from "@/lib/iono/hf";

async function fetchJson<T>(url: string, timeoutMs = 30000): Promise<T | null> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(url, { signal: ctrl.signal, cache: "no-store" });
    clearTimeout(timer);
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

export default function Home() {
  const [sw, setSw] = useState<SpaceWeatherData | null>(null);
  const [aurora, setAurora] = useState<AuroraData | null>(null);
  const [ionos, setIonos] = useState<IonosondeData | null>(null);
  const [settings, setSettings] = useState<SceneSettings>(DEFAULT_SETTINGS);
  const [txCode, setTxCode] = useState<string | null>(null);
  const [rxCode, setRxCode] = useState<string | null>(null);
  const [linkFreq, setLinkFreq] = useState(14.0);
  const [link, setLink] = useState<LinkResult | null>(null);
  const [legend, setLegend] = useState<{ min: number; max: number }>({ min: 2, max: 10 });
  const [fps, setFps] = useState(60);
  const [ideasOpen, setIdeasOpen] = useState(false);
  const [now, setNow] = useState(() => new Date());

  // ─── polling de datos ───
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const s = await fetchJson<SpaceWeatherData>("/api/space-weather");
      if (alive && s) setSw(s);
    };
    load();
    const t = setInterval(load, 60_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const a = await fetchJson<AuroraData>("/api/aurora", 40000);
      if (alive && a) setAurora(a);
    };
    load();
    const t = setInterval(load, 300_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const i = await fetchJson<IonosondeData>("/api/ionosondes", 120_000);
      if (alive && i) setIonos(i);
    };
    load();
    const t = setInterval(load, 600_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  // reloj
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // ─── selección de estaciones: 1º TX, 2º RX, 3º reset ───
  const onStationPick = useCallback(
    (code: string | null) => {
      if (!code) return;
      if (!txCode) {
        setTxCode(code);
        setRxCode(null);
      } else if (!rxCode) {
        if (code === txCode) {
          setTxCode(null);
        } else setRxCode(code);
      } else {
        setTxCode(null);
        setRxCode(null);
      }
    },
    [txCode, rxCode]
  );

  const onSettingsChange = useCallback((patch: Partial<SceneSettings>) => {
    setSettings((s) => ({ ...s, ...patch }));
  }, []);

  const effSec = useMemo(
    () => (Date.now() - (settings.timeMode === "replay" ? settings.replayMinutes * 60_000 : 0)) / 1000,
    [settings.timeMode, settings.replayMinutes, now]
  );

  const tx = ionos?.stations.find((s) => s.code === txCode) ?? null;
  const rx = ionos?.stations.find((s) => s.code === rxCode) ?? null;

  const dataOk = !!(sw && aurora && ionos);

  return (
    <main className="relative w-full h-screen overflow-hidden bg-[#02040a] select-none">
      {/* escena 3D */}
      <IonosphereScene
        spaceWeather={sw}
        aurora={aurora}
        ionosondes={ionos}
        settings={settings}
        txCode={txCode}
        rxCode={rxCode}
        linkFreq={linkFreq}
        callbacks={{
          onStationPick,
          onLinkResult: setLink,
          onLegendRange: (min, max) => setLegend({ min, max }),
          onFps: setFps,
        }}
      />

      {/* cabecera */}
      <header className="absolute top-0 inset-x-0 z-20 pointer-events-none">
        <div className="flex items-start justify-between px-4 md:px-5 pt-3">
          <div className="pointer-events-auto">
            <h1
              className="text-sm md:text-base font-semibold text-slate-100 tracking-wide"
              style={{ fontFamily: "var(--font-display), ui-sans-serif" }}
            >
              IONOSPHERE LIVE 3D
              <span className="ml-2 text-[10px] font-normal uppercase tracking-[0.25em] text-cyan-400/70">
                web explorer
              </span>
            </h1>
            <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
              <span className="font-mono tabular-nums">{now.toISOString().slice(11, 19)} UTC</span>
              <span className="w-1 h-1 rounded-full bg-cyan-400/60" />
              <span className="font-mono">
                subsolar {subsolar(now).lat.toFixed(0)}° {subsolar(now).lon >= 0 ? "E" : "W"}{" "}
                {Math.abs(subsolar(now).lon).toFixed(0)}°
              </span>
            </p>
          </div>
          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              onClick={() => setIdeasOpen(true)}
              className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-xl bg-cyan-500/15 text-cyan-200 ring-1 ring-cyan-400/30 hover:bg-cyan-500/25 transition-colors backdrop-blur-md"
            >
              <FlaskConical size={13} />
              <span className="hidden sm:inline">Explorar ideas</span>
              <span className="sm:hidden">Ideas</span>
              <span className="text-[9px] bg-cyan-400/20 rounded-full px-1.5 py-0.5">21</span>
            </button>
            <a
              href="https://github.com/davidlopezsalvador/ionosphere-live-3d"
              target="_blank"
              rel="noreferrer"
              className="text-slate-500 hover:text-slate-200 transition-colors p-2 rounded-xl hover:bg-white/5"
              title="Repositorio original (C++/OpenGL)"
            >
              <Github size={16} />
            </a>
          </div>
        </div>
      </header>

      {/* paneles laterales */}
      <div className="absolute left-4 top-20 z-10 w-60 pointer-events-none space-y-3 hidden md:block">
        <SpaceWeatherPanel sw={sw} />
      </div>
      <div className="absolute right-4 top-20 z-10 w-64 pointer-events-none space-y-3 hidden md:block">
        <LayersPanel settings={settings} onChange={onSettingsChange} ionosondes={ionos} fps={fps} />
        <RadioPanel link={link} tx={tx} rx={rx} freq={linkFreq} onFreq={setLinkFreq} sw={sw ? { kp: sw.kp.now, xray: sw.xray.now } : null} utcSec={effSec} />
      </div>

      {/* móvil: paneles compactos colapsables */}
      <MobilePanels
        sw={sw}
        settings={settings}
        onChange={onSettingsChange}
        ionos={ionos}
        fps={fps}
        link={link}
        tx={tx}
        rx={rx}
        freq={linkFreq}
        onFreq={setLinkFreq}
        effSec={effSec}
      />

      {/* barra de tiempo inferior */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10">
        <TimeBar settings={settings} onChange={onSettingsChange} maxReplayMin={360} />
      </div>

      {/* leyenda */}
      <div className="absolute bottom-4 right-4 z-10 hidden md:block">
        <Legend
          min={legend.min}
          max={legend.max}
          timestamp={
            settings.timeMode === "replay"
              ? `replay −${(settings.replayMinutes / 60).toFixed(1)} h`
              : ionos
              ? "live"
              : "…"
          }
        />
      </div>

      {/* indicador de selección TX/RX */}
      {(txCode || rxCode) && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="flex items-center gap-2 text-xs bg-[#0a0f1e]/85 backdrop-blur-md ring-1 ring-white/10 rounded-full px-3.5 py-1.5">
            {txCode ? (
              <span className="flex items-center gap-1 text-cyan-300 font-mono">
                <RadioTower size={11} /> {txCode}
              </span>
            ) : (
              <span className="text-slate-500">haz clic para TX</span>
            )}
            {rxCode ? (
              <span className="flex items-center gap-1 text-amber-300 font-mono">
                <Signal size={11} /> {rxCode}
              </span>
            ) : txCode ? (
              <span className="text-slate-500">· segundo clic = RX</span>
            ) : null}
            {txCode && rxCode && (
              <button
                className="pointer-events-auto text-slate-500 hover:text-red-300 transition-colors"
                onClick={() => {
                  setTxCode(null);
                  setRxCode(null);
                }}
              >
                <X size={12} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* overlay de carga inicial */}
      {!dataOk && (
        <div className="absolute inset-0 z-30 bg-[#02040a]/80 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 rounded-full border-2 border-cyan-400/20" />
            <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-cyan-400 animate-spin" />
            <div className="absolute inset-3 rounded-full bg-cyan-400/10 animate-pulse" />
          </div>
          <p className="text-xs text-slate-400 tracking-wide">
            Conectando con NOAA SWPC · GIRO · SDO…
          </p>
          <div className="flex gap-2 text-[10px]">
            <StatusChip ok={!!sw} label="clima espacial" />
            <StatusChip ok={!!aurora} label="aurora" />
            <StatusChip ok={!!ionos} label="ionosondas" />
          </div>
        </div>
      )}

      <IdeasPanel open={ideasOpen} onClose={() => setIdeasOpen(false)} />

      {/* pie: fuentes */}
      <footer className="absolute bottom-4 left-4 z-10 text-[9px] text-slate-600 pointer-events-none hidden lg:block leading-relaxed">
        NOAA SWPC · GIRO DIDBase (CC BY-NC-SA 4.0) · SDO (NASA/SDO &amp; AIA, HMI consortium)
        <br />
        Exploración derivada del repositorio C++ ionosphere-live-3d
      </footer>
    </main>
  );
}

function StatusChip({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span
      className={`flex items-center gap-1.5 px-2 py-1 rounded-full ring-1 ${
        ok ? "bg-emerald-500/10 text-emerald-300 ring-emerald-400/30" : "bg-white/5 text-slate-500 ring-white/10"
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${ok ? "bg-emerald-400" : "bg-slate-600 animate-pulse"}`} />
      {label}
    </span>
  );
}

function subsolar(now: Date) {
  // aproximación rápida para el HUD (el shader usa Meeus exacto)
  const doy = Math.floor((now.getTime() - Date.UTC(now.getUTCFullYear(), 0, 0)) / 86400000);
  const decl = 23.44 * Math.sin((2 * Math.PI * (doy - 81)) / 365);
  const utcH = now.getUTCHours() + now.getUTCMinutes() / 60;
  let lon = (12 - utcH) * 15;
  if (lon > 180) lon -= 360;
  if (lon < -180) lon += 360;
  return { lat: decl, lon };
}

/** En móvil: paneles en pestañas colapsables */
function MobilePanels({
  sw,
  settings,
  onChange,
  ionos,
  fps,
  link,
  tx,
  rx,
  freq,
  onFreq,
  effSec,
}: {
  sw: SpaceWeatherData | null;
  settings: SceneSettings;
  onChange: (p: Partial<SceneSettings>) => void;
  ionos: IonosondeData | null;
  fps: number;
  link: LinkResult | null;
  tx: { code: string; name: string; lat: number; lon: number } | null;
  rx: { code: string; name: string; lat: number; lon: number } | null;
  freq: number;
  onFreq: (f: number) => void;
  effSec: number;
}) {
  const [tab, setTab] = useState<"wx" | "radio" | "layers" | null>(null);
  return (
    <div className="md:hidden absolute left-3 right-3 top-16 z-10">
      <div className="flex gap-1.5 mb-2 pointer-events-auto">
        {(
          [
            ["wx", "Clima"],
            ["radio", "Radio"],
            ["layers", "Capas"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(tab === id ? null : id)}
            className={`text-[11px] px-3 py-1.5 rounded-lg backdrop-blur-md transition-colors ${
              tab === id
                ? "bg-cyan-500/20 text-cyan-200 ring-1 ring-cyan-400/30"
                : "bg-[#0a0f1e]/80 text-slate-400 ring-1 ring-white/10"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
      {tab === "wx" && <SpaceWeatherPanel sw={sw} />}
      {tab === "radio" && (
        <RadioPanel
          link={link}
          tx={tx as never}
          rx={rx as never}
          freq={freq}
          onFreq={onFreq}
          sw={sw ? { kp: sw.kp.now, xray: sw.xray.now } : null}
          utcSec={effSec}
        />
      )}
      {tab === "layers" && (
        <LayersPanel settings={settings} onChange={onChange} ionosondes={ionos} fps={fps} />
      )}
    </div>
  );
}
