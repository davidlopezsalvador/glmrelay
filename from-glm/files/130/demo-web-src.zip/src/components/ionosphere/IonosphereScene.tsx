"use client";

/**
 * Escena 3D principal: Tierra + atmósfera real + ionosfera + aurora + rayos HF.
 * Ciclo de vida React: montaje único, actualizaciones por props, loop rAF.
 */

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";

import { getSunInfo } from "@/lib/iono/solar";
import { buildFoF2Grid, buildHmF2Grid, sampleGrid, GRID_W, GRID_H } from "@/lib/iono/ionomath";
import { computeLink, LinkResult } from "@/lib/iono/hf";
import { latLonToVec3 } from "@/lib/iono/geo";

import {
  buildStars,
  buildEarth,
  buildAtmosphere,
  buildColormapTexture,
  buildIonShell,
  updateShellTextures,
  buildAurora,
  buildStations,
  buildLinkTube,
  buildRefRings,
  buildSunGlow,
} from "./builders";
import {
  SpaceWeatherData,
  AuroraData,
  IonosondeData,
  IonosondeStation,
  SceneSettings,
  sampleStationAt,
} from "./types";

export interface SceneCallbacks {
  onStationPick?: (code: string | null) => void;
  onLinkResult?: (r: LinkResult | null) => void;
  onLegendRange?: (min: number, max: number) => void;
  onFps?: (fps: number) => void;
}

interface Props {
  spaceWeather: SpaceWeatherData | null;
  aurora: AuroraData | null;
  ionosondes: IonosondeData | null;
  settings: SceneSettings;
  txCode: string | null;
  rxCode: string | null;
  linkFreq: number;
  callbacks: SceneCallbacks;
}

export default function IonosphereScene(props: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const propsRef = useRef(props);
  propsRef.current = props;

  // objetos mutables de escena (viven fuera de React)
  const S = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    composer: EffectComposer;
    bloom: UnrealBloomPass;
    earthMat?: THREE.ShaderMaterial;
    atmoMat?: THREE.ShaderMaterial;
    shellObj?: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial; foTex: THREE.DataTexture; hmTex: THREE.DataTexture };
    auroraObj?: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial };
    stationsObj?: { points: THREE.Points; mat: THREE.ShaderMaterial; codes: string[] };
    rings?: THREE.Group;
    sunGlow?: { core: THREE.Sprite; halo: THREE.Sprite };
    starMat?: THREE.ShaderMaterial;
    linkObj?: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial };
    raycaster: THREE.Raycaster;
    gridState: {
      fo: Float32Array;
      hm: Float32Array;
      fMin: number;
      fMax: number;
      stamp: number;
    };
    disposables: { dispose(): void }[];
    lastLinkKey: string;
    lastGridStamp: number;
  } | null>(null);

  // ───────── montaje: construir escena una vez ─────────
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    let disposed = false;

    const init = async () => {
      const dayLoader = new THREE.TextureLoader().loadAsync("/textures/earth-day.jpg");
      const nightLoader = new THREE.TextureLoader().loadAsync("/textures/earth-night.jpg");
      const [dayTex, nightTex] = await Promise.all([dayLoader, nightLoader]);
      if (disposed) return;
      dayTex.colorSpace = THREE.SRGBColorSpace;
      nightTex.colorSpace = THREE.SRGBColorSpace;
      dayTex.anisotropy = 8;
      nightTex.anisotropy = 4;

      const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(mount.clientWidth, mount.clientHeight);
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.12;
      mount.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x02040a);

      const camera = new THREE.PerspectiveCamera(42, mount.clientWidth / mount.clientHeight, 0.05, 200);
      // vista inicial: Atlántico/Europa (lado diurno para el hemisferio N al mediodía UTC)
      const [cx, cy, cz] = latLonToVec3(28, -28, 3.3);
      camera.position.set(cx, cy, cz);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.06;
      controls.minDistance = 1.12;
      controls.maxDistance = 9;
      controls.enablePan = false;
      controls.autoRotate = propsRef.current.settings.cinema;
      controls.autoRotateSpeed = 0.35;

      // post: composer con MSAA 4x en el target HDR
      const size = renderer.getDrawingBufferSize(new THREE.Vector2());
      const rt = new THREE.WebGLRenderTarget(size.x, size.y, {
        type: THREE.HalfFloatType,
        samples: 4,
      });
      const composer = new EffectComposer(renderer, rt);
      composer.addPass(new RenderPass(scene, camera));
      const bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.55, 0.5, 0.72);
      composer.addPass(bloom);
      composer.addPass(new OutputPass());

      // objetos
      const stars = buildStars(Math.min(window.devicePixelRatio, 2));
      scene.add(stars.points);
      const earth = buildEarth(dayTex, nightTex);
      scene.add(earth.mesh);
      const atmo = buildAtmosphere();
      scene.add(atmo.mesh);
      const cmapTex = buildColormapTexture("viridis");
      const shell = buildIonShell(cmapTex);
      scene.add(shell.mesh);
      const rings = buildRefRings();
      scene.add(rings.group);
      const sunGlow = buildSunGlow();
      scene.add(sunGlow.core, sunGlow.halo);

      S.current = {
        renderer,
        scene,
        camera,
        controls,
        composer,
        bloom,
        earthMat: earth.mat,
        atmoMat: atmo.mat,
        shellObj: shell,
        rings: rings.group,
        sunGlow,
        starMat: stars.mat,
        raycaster: new THREE.Raycaster(),
        gridState: { fo: new Float32Array(GRID_W * GRID_H), hm: new Float32Array(GRID_W * GRID_H), fMin: 2, fMax: 10, stamp: 0 },
        disposables: [dayTex, nightTex, cmapTex, earth.mesh.geometry, earth.mat, atmo.mesh.geometry, atmo.mat, shell.mesh.geometry, shell.mat, shell.foTex, shell.hmTex, rings.group, stars.points.geometry, stars.mat],
        lastLinkKey: "",
        lastGridStamp: -1,
      };

      // resize
      const ro = new ResizeObserver(() => {
        const w = mount.clientWidth,
          h = mount.clientHeight;
        if (w === 0 || h === 0) return;
        renderer.setSize(w, h);
        composer.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      });
      ro.observe(mount);

      // picking manual (proyección a pantalla — preciso con puntos custom)
      let downX = 0,
        downY = 0;
      const onDown = (e: PointerEvent) => {
        downX = e.clientX;
        downY = e.clientY;
      };
      const onUp = (e: PointerEvent) => {
        if (Math.hypot(e.clientX - downX, e.clientY - downY) > 6) return; // drag
        const so = S.current;
        if (!so?.stationsObj) return;
        const rect = renderer.domElement.getBoundingClientRect();
        const px = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        const py = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        const p = new THREE.Vector3();
        let bestIdx = -1,
          bestD = 24; // px umbral
        const codes = so.stationsObj.codes;
        const posAttr = so.stationsObj.points.geometry.attributes.position as THREE.BufferAttribute;
        const cands: { code: string; sx: number; sy: number; dd: number; vis: boolean }[] = [];
        for (let i = 0; i < codes.length; i++) {
          p.fromBufferAttribute(posAttr, i);
          p.project(camera);
          if (p.z > 1) continue;
          const sx = ((p.x + 1) / 2) * rect.width;
          const sy = ((1 - p.y) / 2) * rect.height;
          const dd = Math.hypot(sx - (e.clientX - rect.left), sy - (e.clientY - rect.top));
          // hemisferio visible: dot(dirección estación, dirección cámara)
          const world = p.clone().unproject(camera).normalize();
          const camDir = camera.position.clone().normalize();
          const vis = world.dot(camDir) >= 0.0;
          if (dd < 60) cands.push({ code: codes[i], sx: Math.round(sx), sy: Math.round(sy), dd: Math.round(dd), vis });
          if (dd < bestD) {
            if (!vis) continue; // hemisferio oculto tras el globo
            bestD = dd;
            bestIdx = i;
          }
        }
        (window as unknown as { __pickCands?: unknown[] }).__pickCands = cands;
        propsRef.current.callbacks.onStationPick?.(bestIdx >= 0 ? codes[bestIdx] : null);
        if ((window as unknown as { __debugPick?: boolean }).__debugPick) {
          console.log("[pick] click", e.clientX, e.clientY, "->", bestIdx >= 0 ? codes[bestIdx] : null, "candidates", (window as unknown as { __pickCands?: unknown[] }).__pickCands);
        }
      };
      renderer.domElement.addEventListener("pointerdown", onDown);
      renderer.domElement.addEventListener("pointerup", onUp);

      // loop
      let raf = 0;
      let lastT = performance.now();
      let fpsAcc = 0,
        fpsN = 0,
        fpsT = lastT;
      let elapsed = 0;

      const tick = () => {
        raf = requestAnimationFrame(tick);
        const now = performance.now();
        const dt = Math.min(0.1, (now - lastT) / 1000);
        lastT = now;
        fpsAcc += 1 / Math.max(dt, 1e-4);
        fpsN++;
        if (now - fpsT > 2000) {
          propsRef.current.callbacks.onFps?.(fpsAcc / fpsN);
          fpsAcc = 0;
          fpsN = 0;
          fpsT = now;
        }
        const t = elapsed;
        elapsed += dt;

        // sol por tiempo efectivo (live o replay — mejora: el terminador sigue al dato)
        const { settings } = propsRef.current;
        const effMs = Date.now() - (settings.timeMode === "replay" ? settings.replayMinutes * 60_000 : 0);
        const sun = getSunInfo(effMs / 1000);
        const sunV = new THREE.Vector3(sun.dir[0], sun.dir[1], sun.dir[2]);

        // uniforms
        if (S.current?.earthMat) {
          const u = S.current.earthMat.uniforms;
          u.uSunDir.value.copy(sunV);
          u.uCameraPos.value.copy(camera.position);
          u.uTime.value = t;
          u.uNight.value = propsRef.current.settings.nightLights;
          u.uCloudAmt.value = propsRef.current.settings.clouds ? 0.55 : 0;
        }
        if (S.current?.atmoMat) {
          const u = S.current.atmoMat.uniforms;
          u.uSunDir.value.copy(sunV);
          u.uCameraPos.value.copy(camera.position);
          const q = propsRef.current.settings.atmoQuality;
          u.uSteps.value = q === "low" ? 6 : q === "medium" ? 10 : 14;
          u.uLightSteps.value = q === "low" ? 3 : q === "medium" ? 4 : 5;
        }
        if (S.current?.shellObj) {
          const u = S.current.shellObj.mat.uniforms;
          u.uSunDir.value.copy(sunV);
          u.uCameraPos.value.copy(camera.position);
          u.uTime.value = t;
          u.uKp.value = propsRef.current.spaceWeather?.kp.now ?? 2;
          u.uExaggeration.value = propsRef.current.settings.exaggeration;
          u.uOpacity.value = propsRef.current.settings.shellOpacity;
          S.current.shellObj.mesh.visible = propsRef.current.settings.showShell;
        }
        if (S.current?.auroraObj) {
          const u = S.current.auroraObj.mat.uniforms;
          u.uTime.value = t;
          S.current.auroraObj.mesh.visible = propsRef.current.settings.showAurora;
        }
        if (S.current?.stationsObj) {
          S.current.stationsObj.mat.uniforms.uTime.value = t;
          S.current.stationsObj.points.visible = propsRef.current.settings.showStations;
        }
        if (S.current?.starMat) S.current.starMat.uniforms.uTime.value = t;
        if (S.current?.linkObj) {
          S.current.linkObj.mat.uniforms.uTime.value = t;
          S.current.linkObj.mesh.visible = propsRef.current.settings.showLink;
        }
        if (S.current?.rings) {
          S.current.rings.visible = propsRef.current.settings.showRings;
          // anillos siguen la exageración
          const ex = propsRef.current.settings.exaggeration;
          const defs = [90, 110, 170, 300];
          let li = 0;
          for (const child of S.current.rings.children) {
            if ((child as THREE.Line).isLine) {
              const r = 1 + (defs[li] / 6371) * ex;
              const pos = (child as THREE.Line).geometry.attributes.position as THREE.BufferAttribute;
              for (let i = 0; i < pos.count; i++) {
                const [x, y, z] = latLonToVec3(0, (i / (pos.count - 1)) * 360 - 180, r);
                pos.setXYZ(i, x, y, z);
              }
              pos.needsUpdate = true;
              li++;
            }
          }
        }
        // sol: sprites a 6.5 unidades
        if (S.current?.sunGlow) {
          const p = sunV.clone().multiplyScalar(6.5);
          S.current.sunGlow.core.position.copy(p);
          S.current.sunGlow.halo.position.copy(p);
        }

        controls.autoRotate = propsRef.current.settings.cinema;
        controls.update();
        composer.render();
      };
      tick();

      return () => {
        ro.disconnect();
        renderer.domElement.removeEventListener("pointerdown", onDown);
        renderer.domElement.removeEventListener("pointerup", onUp);
        cancelAnimationFrame(raf);
      };
    };

    let cleanupScene: (() => void) | undefined;
    init()
      .then((c) => {
        cleanupScene = c;
      })
      .catch((err) => console.error("[scene] init failed", err));

    return () => {
      disposed = true;
      cleanupScene?.();
      const so = S.current;
      if (so) {
        so.controls.dispose();
        so.disposables.forEach((d) => d.dispose());
        so.stationsObj?.points.geometry.dispose();
        so.stationsObj?.mat.dispose();
        so.auroraObj?.mesh.geometry.dispose();
        so.auroraObj?.mat.dispose();
        so.linkObj?.mesh.geometry.dispose();
        so.linkObj?.mat.dispose();
        so.renderer.dispose();
        so.renderer.domElement.remove();
        S.current = null;
      }
    };
    
  }, []);

  // ───────── datos: ionosondas → grids + puntos ─────────
  useEffect(() => {
    const so = S.current;
    if (!so || !props.ionosondes) return;
    const { settings } = props;
    const effMs = Date.now() - (settings.timeMode === "replay" ? settings.replayMinutes * 60_000 : 0);

    // estaciones muestreadas al tiempo efectivo
    const sampled: IonosondeStation[] = props.ionosondes.stations.map((s) => ({
      ...s,
      foF2: sampleStationAt(s, effMs),
    }));

    const f107 = props.spaceWeather?.f107.now ?? 110;
    const foGrid = buildFoF2Grid(sampled, effMs / 1000, f107, true);
    const hmGrid = buildHmF2Grid(sampled, effMs / 1000);

    // rango robusto (percentiles para no romper el colormap con outliers)
    const sorted = [...foGrid.values].sort((a, b) => a - b);
    const fMin = sorted[Math.floor(sorted.length * 0.02)];
    const fMax = sorted[Math.floor(sorted.length * 0.98)];
    const span = Math.max(1.5, fMax - fMin);

    updateShellTextures(so.shellObj!.foTex, so.shellObj!.hmTex, foGrid.values, hmGrid.values, fMin, fMin + span);
    so.gridState = { fo: foGrid.values, hm: hmGrid.values, fMin, fMax: fMin + span, stamp: Date.now() };
    props.callbacks.onLegendRange?.(fMin, fMin + span);

    // rebuild estaciones (posiciones fijas, color por foF2)
    if (so.stationsObj) {
      so.scene.remove(so.stationsObj.points);
      so.stationsObj.points.geometry.dispose();
      so.stationsObj.mat.dispose();
    }
    if (so.auroraObj === undefined) {
      // nada
    }
    const cmapTex = so.disposables.find((d) => (d as THREE.DataTexture).isTexture && (d as THREE.DataTexture).image?.width === 256) as THREE.DataTexture;
    const st = buildStations(sampled, cmapTex, fMin, fMin + span);
    so.scene.add(st.points);
    so.stationsObj = st;
    so.lastGridStamp = so.gridState.stamp;
  }, [props.ionosondes, props.spaceWeather?.f107.now, props.settings.timeMode, props.settings.replayMinutes]);

  // ───────── datos: aurora → instancias ─────────
  useEffect(() => {
    const so = S.current;
    if (!so) return;
    if (so.auroraObj) {
      so.scene.remove(so.auroraObj.mesh);
      so.auroraObj.mesh.geometry.dispose();
      so.auroraObj.mat.dispose();
      so.auroraObj = undefined;
    }
    if (!props.aurora || !props.aurora.cells.length) return;
    const au = buildAurora(props.aurora.cells);
    so.scene.add(au.mesh);
    so.auroraObj = au;
    au.mesh.visible = props.settings.showAurora;
  }, [props.aurora]);

  // ───────── enlace HF (TX/RX/frecuencia/grid) ─────────
  useEffect(() => {
    const so = S.current;
    if (!so) return;
    const { txCode, rxCode, linkFreq, settings } = props;
    if (!txCode || !rxCode || !props.ionosondes) {
      if (so.linkObj) {
        so.scene.remove(so.linkObj.mesh);
        so.linkObj.mesh.geometry.dispose();
        so.linkObj.mat.dispose();
        so.linkObj = undefined;
      }
      props.callbacks.onLinkResult?.(null);
      return;
    }
    const tx = props.ionosondes.stations.find((s) => s.code === txCode);
    const rx = props.ionosondes.stations.find((s) => s.code === rxCode);
    if (!tx || !rx) return;

    const key = `${txCode}|${rxCode}|${linkFreq}|${settings.exaggeration}|${so.gridState.stamp}`;
    if (key === so.lastLinkKey) return;
    so.lastLinkKey = key;

    const foAt = (ll: { lat: number; lon: number }) =>
      sampleGrid({ w: GRID_W, h: GRID_H, values: so.gridState!.fo, min: 0, max: 0 }, ll.lat, ll.lon);
    const hmAt = (ll: { lat: number; lon: number }) =>
      sampleGrid({ w: GRID_W, h: GRID_H, values: so.gridState!.hm, min: 0, max: 0 }, ll.lat, ll.lon);

    const link = computeLink(
      { lat: tx.lat, lon: tx.lon },
      { lat: rx.lat, lon: rx.lon },
      foAt,
      hmAt,
      linkFreq
    );
    props.callbacks.onLinkResult?.(link);

    if (so.linkObj) {
      so.scene.remove(so.linkObj.mesh);
      so.linkObj.mesh.geometry.dispose();
      so.linkObj.mat.dispose();
      so.linkObj = undefined;
    }
    const tube = buildLinkTube(link.points3D, settings.exaggeration);
    so.scene.add(tube.mesh);
    tube.mesh.renderOrder = 5;
    so.linkObj = tube;
  }, [props.txCode, props.rxCode, props.linkFreq, props.ionosondes, props.settings.exaggeration, props.settings.timeMode, props.settings.replayMinutes]);

  return <div ref={mountRef} className="absolute inset-0" aria-label="Escena 3D del globo ionosférico" />;
}
