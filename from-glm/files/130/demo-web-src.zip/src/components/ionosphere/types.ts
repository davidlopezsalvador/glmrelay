/** Tipos compartidos cliente (espejo de las APIs) */

export interface KpPoint {
  t: number;
  kp: number;
}

export interface SpaceWeatherData {
  updated: number;
  utc: string;
  kp: { now: number; gScale: number; series: KpPoint[]; source: string };
  f107: { now: number; series: { t: number; f: number }[]; source: string };
  wind: { speed: number; bt: number; bz: number; t: string | null; source: string };
  xray: { now: number; class: string; series: { t: number; f: number }[]; source: string };
  sunspots: {
    regions: { region: number; lat: number; lon: number; loc: string }[];
    source: string;
  };
  forecast: { maxKp: number | null; note: string; source: string };
}

export interface AuroraCell {
  lat: number;
  lon: number;
  p: number; // 0-100
}

export interface AuroraData {
  updated: number;
  observationTime: string;
  forecastTime: string;
  cells: AuroraCell[];
  source: string;
}

export interface StationHistoryPoint {
  t: string; // ISO
  foF2: number;
}

export interface IonosondeStation {
  code: string;
  name: string;
  lat: number;
  lon: number;
  foF2: number | null;
  muf3000: number | null;
  history: StationHistoryPoint[];
}

export interface IonosondeData {
  updated: number;
  stations: IonosondeStation[];
  total: number;
  catalogSize: number;
  source: string;
}

export interface SceneSettings {
  clouds: boolean;
  atmoQuality: "low" | "medium" | "high";
  showAurora: boolean;
  showShell: boolean;
  showStations: boolean;
  showRings: boolean;
  showLink: boolean;
  exaggeration: number; // 1..5
  shellOpacity: number; // 0..1
  nightLights: number; // 0..1
  cinema: boolean;
  timeMode: "live" | "replay";
  replayMinutes: number; // 0..360 (6h de historia GIRO)
}

export const DEFAULT_SETTINGS: SceneSettings = {
  clouds: true,
  atmoQuality: "high",
  showAurora: true,
  showShell: true,
  showStations: true,
  showRings: true,
  showLink: true,
  exaggeration: 2.2,
  shellOpacity: 0.85,
  nightLights: 0.45,
  cinema: true,
  timeMode: "live",
  replayMinutes: 0,
};

/** Muestrear la historia de una estación en un instante (lerp como sampleHistoryAt del C++) */
export function sampleStationAt(
  s: IonosondeStation,
  epochMs: number
): number | null {
  const h = s.history;
  if (!h || h.length === 0) return s.foF2;
  const ts = h.map((x) => Date.parse(x.t.endsWith("Z") ? x.t : x.t + "Z"));
  if (epochMs <= ts[0]) return h[0].foF2;
  if (epochMs >= ts[ts.length - 1]) return h[h.length - 1].foF2;
  let lo = 0,
    hi = ts.length - 1;
  while (hi - lo > 1) {
    const m = (lo + hi) >> 1;
    if (ts[m] <= epochMs) lo = m;
    else hi = m;
  }
  const f = (epochMs - ts[lo]) / (ts[hi] - ts[lo] || 1);
  const a = h[lo].foF2,
    b = h[hi].foF2;
  if (a <= 0) return b;
  if (b <= 0) return a;
  return a + f * (b - a);
}
