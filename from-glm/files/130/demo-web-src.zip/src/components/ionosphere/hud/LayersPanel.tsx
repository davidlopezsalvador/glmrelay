"use client";

import { Layers, Cloud, Sparkles, Radio, Orbit, Mountain, Eye, Disc3 } from "lucide-react";
import { SceneSettings, IonosondeData } from "../types";
import { PanelBox, SourceDot } from "./SpaceWeatherPanel";

interface Props {
  settings: SceneSettings;
  onChange: (patch: Partial<SceneSettings>) => void;
  ionosondes: IonosondeData | null;
  fps: number;
}

/** Panel de capas y controles visuales */
export default function LayersPanel({ settings, onChange, ionosondes, fps }: Props) {
  const n = ionosondes?.stations.length ?? 0;
  const withData = ionosondes?.stations.filter((s) => (s.foF2 ?? 0) > 0).length ?? 0;
  return (
    <PanelBox title="Capas" badge={<span className="text-[10px] text-slate-500 font-mono">{fps.toFixed(0)} fps</span>}>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
        <Toggle
          icon={<Cloud size={12} />}
          label="Nubes"
          checked={settings.clouds}
          onChange={(v) => onChange({ clouds: v })}
        />
        <Toggle
          icon={<Sparkles size={12} />}
          label="Aurora"
          checked={settings.showAurora}
          onChange={(v) => onChange({ showAurora: v })}
        />
        <Toggle
          icon={<Radio size={12} />}
          label="Enlace HF"
          checked={settings.showLink}
          onChange={(v) => onChange({ showLink: v })}
        />
        <Toggle
          icon={<Orbit size={12} />}
          label="Modo cine"
          checked={settings.cinema}
          onChange={(v) => onChange({ cinema: v })}
        />
        <Toggle
          icon={<Disc3 size={12} />}
          label="Shell foF2"
          checked={settings.showShell}
          onChange={(v) => onChange({ showShell: v })}
        />
        <Toggle
          icon={<Eye size={12} />}
          label="Ionosondas"
          checked={settings.showStations}
          onChange={(v) => onChange({ showStations: v })}
        />
      </div>

      <Slider
        icon={<Mountain size={12} />}
        label="Exageración alt."
        value={settings.exaggeration}
        min={1}
        max={5}
        step={0.1}
        format={(v) => `${v.toFixed(1)}×`}
        onChange={(v) => onChange({ exaggeration: v })}
      />
      <Slider
        icon={<Layers size={12} />}
        label="Opacidad shell"
        value={settings.shellOpacity}
        min={0.1}
        max={1}
        step={0.05}
        format={(v) => `${(v * 100).toFixed(0)}%`}
        onChange={(v) => onChange({ shellOpacity: v })}
      />

      <div className="mt-2 pt-2 border-t border-white/10 text-[11px] text-slate-400 flex items-center justify-between">
        <span>Ionosondas GIRO</span>
        <span className="flex items-center gap-1.5">
          <SourceDot source={ionosondes ? ionosondes.source : ""} />
          {withData}/{n}
        </span>
      </div>
    </PanelBox>
  );
}

function Toggle({
  icon,
  label,
  checked,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`flex items-center gap-1.5 text-xs rounded-lg px-2 py-1.5 transition-colors ${
        checked
          ? "bg-cyan-500/15 text-cyan-200 ring-1 ring-cyan-400/30"
          : "bg-white/5 text-slate-500 hover:bg-white/10 ring-1 ring-transparent"
      }`}
    >
      {icon}
      <span className="flex-1 text-left">{label}</span>
      <span
        className={`w-1.5 h-1.5 rounded-full ${checked ? "bg-cyan-300" : "bg-slate-600"}`}
      />
    </button>
  );
}

function Slider({
  icon,
  label,
  value,
  min,
  max,
  step,
  format,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (v: number) => string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="mt-2">
      <div className="flex items-center justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1.5">
          {icon} {label}
        </span>
        <span className="text-slate-200 font-mono">{format(value)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full mt-1 h-1.5 rounded-full appearance-none cursor-pointer
          [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3.5 [&::-webkit-slider-thumb]:h-3.5
          [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-cyan-300
          [&::-webkit-slider-thumb]:shadow-[0_0_8px_rgba(34,211,238,0.6)]
          [&::-webkit-slider-runnable-track]:bg-white/10
          bg-white/10"
      />
    </div>
  );
}
