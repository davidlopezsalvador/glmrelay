"use client";

import { useState } from "react";
import { Clock, Play, Pause, RotateCcw } from "lucide-react";
import { SceneSettings } from "../types";

interface Props {
  settings: SceneSettings;
  onChange: (patch: Partial<SceneSettings>) => void;
  maxReplayMin: number;
}

/** Barra de tiempo: LIVE vs REPLAY (historia GIRO 6 h) */
export default function TimeBar({ settings, onChange, maxReplayMin }: Props) {
  const [scrubbing, setScrubbing] = useState(false);
  const replay = settings.timeMode === "replay";
  const minutesBack = maxReplayMin - settings.replayMinutes; // slider: 0 = presente
  const eff = new Date(Date.now() - settings.replayMinutes * 60_000);

  return (
    <div
      className="pointer-events-auto rounded-xl border border-white/10 bg-[#0a0f1e]/85 backdrop-blur-md shadow-2xl px-3 py-2 flex items-center gap-3"
      style={{ fontFamily: "var(--font-display), ui-sans-serif, system-ui" }}
    >
      <button
        onClick={() => onChange({ timeMode: replay ? "live" : "replay", replayMinutes: 0 })}
        className={`flex items-center gap-1.5 text-[11px] font-semibold rounded-lg px-2.5 py-1.5 transition-colors ${
          replay ? "bg-amber-500/20 text-amber-300 ring-1 ring-amber-400/40" : "bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/40"
        }`}
        title="Alternar LIVE / REPLAY"
      >
        {replay ? <Pause size={12} /> : <Play size={12} />}
        {replay ? "REPLAY" : "LIVE"}
      </button>

      <div className="flex items-center gap-1.5 text-slate-400">
        <Clock size={13} />
        <span className="font-mono text-xs tabular-nums text-slate-200">
          {eff.toISOString().slice(11, 16)} UTC
        </span>
      </div>

      <div className="relative w-56 md:w-72">
        <input
          type="range"
          min={0}
          max={maxReplayMin}
          step={5}
          value={minutesBack}
          disabled={!replay}
          onPointerDown={() => setScrubbing(true)}
          onPointerUp={() => setScrubbing(false)}
          onChange={(e) => {
            const back = parseFloat(e.target.value);
            onChange({ timeMode: back > 0 ? "replay" : "live", replayMinutes: back });
          }}
          className={`w-full h-1.5 rounded-full appearance-none cursor-pointer transition-opacity ${
            replay ? "opacity-100 bg-gradient-to-r from-cyan-500/30 to-emerald-400/40" : "opacity-30 bg-white/10"
          }
            [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3.5 [&::-webkit-slider-thumb]:h-3.5
            [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-cyan-300
            [&::-webkit-slider-thumb]:shadow-[0_0_8px_rgba(34,211,238,0.7)]`}
        />
        <div className="flex justify-between text-[9px] text-slate-600 mt-0.5 select-none">
          <span>−{maxReplayMin / 60} h</span>
          <span>{scrubbing ? "hist. GIRO · 5 min/frame" : "ahora"}</span>
        </div>
      </div>

      {settings.replayMinutes > 0 && (
        <button
          onClick={() => onChange({ timeMode: "live", replayMinutes: 0 })}
          className="text-slate-400 hover:text-cyan-300 transition-colors"
          title="Volver a tiempo real"
        >
          <RotateCcw size={13} />
        </button>
      )}
    </div>
  );
}
