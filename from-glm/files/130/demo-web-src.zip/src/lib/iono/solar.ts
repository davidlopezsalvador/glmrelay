/**
 * Posición solar (Meeus de baja precisión) — port de src/Utils/SolarPosition.cpp
 * Devuelve dirección unitaria del sol y punto subsolar (lat, lon).
 */

import { DEG, RAD, vec3ToLatLon } from "./geo";

export interface SunInfo {
  dir: [number, number, number];
  subsolarLat: number;
  subsolarLon: number;
}

export function getSunInfo(utcSeconds: number): SunInfo {
  const j2000 = utcSeconds / 86400.0 + 10957.5; // días desde J2000.0
  const T = j2000 / 36525.0; // siglos

  const L0 = mod(280.46646 + 36000.76983 * T + 0.0003032 * T * T, 360.0);
  const M = mod(357.52911 + 35999.05029 * T - 0.0001537 * T * T, 360.0);
  const Mrad = M * DEG;

  const C =
    (1.914602 - 0.004817 * T) * Math.sin(Mrad) +
    (0.019993 - 0.000101 * T) * Math.sin(2.0 * Mrad) +
    0.000289 * Math.sin(3.0 * Mrad);

  const lonEcl = (L0 + C) * DEG;
  const obliquity = (23.439291 - 0.0130042 * T) * DEG;

  const x = Math.cos(lonEcl);
  const y = Math.sin(lonEcl) * Math.cos(obliquity);
  const z = Math.sin(lonEcl) * Math.sin(obliquity);

  const GMST = mod(280.46061837 + 360.98564736629 * j2000 + 0.000387933 * T * T, 360.0);
  const rotation = GMST * DEG;

  const fx = x * Math.cos(rotation) + y * Math.sin(rotation);
  const fy = -x * Math.sin(rotation) + y * Math.cos(rotation);

  const dir: [number, number, number] = normalize([-fx, z, fy]);
  const { lat, lon } = vec3ToLatLon(dir[0], dir[1], dir[2]);
  return { dir, subsolarLat: lat, subsolarLon: lon };
}

function normalize(v: [number, number, number]): [number, number, number] {
  const m = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / m, v[1] / m, v[2] / m];
}

function mod(a: number, b: number): number {
  return ((a % b) + b) % b;
}

/** Ángulo cenital solar (grados) para un punto dado */
export function solarZenithDeg(latDeg: number, lonDeg: number, utcSeconds: number): number {
  const { dir } = getSunInfo(utcSeconds);
  const DEG2 = Math.PI / 180;
  const lat = latDeg * DEG2;
  const phi = (lonDeg + 180) * DEG2;
  const px = -Math.cos(phi) * Math.cos(lat);
  const py = Math.sin(lat);
  const pz = Math.sin(phi) * Math.cos(lat);
  const d = px * dir[0] + py * dir[1] + pz * dir[2];
  return Math.acos(Math.max(-1, Math.min(1, d))) * RAD;
}
